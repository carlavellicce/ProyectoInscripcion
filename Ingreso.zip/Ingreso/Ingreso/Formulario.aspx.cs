﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ingreso
{
    public partial class Formulario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string dni = (string)(Session["DNI"]);
            TextBox3.Text = dni;




/*
            if (!IsPostBack)
            {
                using (SqlConnection cnn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='c:\users\emylavenia\documents\visual studio 2015\Projects\Ingreso\Ingreso\App_Data\IngresoDB.mdf';Integrated Security=True"))
                {
                    DataTable dt = new DataTable();
                    string query = "SELECT * FROM Provincia";

                    SqlCommand cmd = new SqlCommand(query, cnn);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);

                    ComboProvincia.DataSource = dt;
                    ComboProvincia.DataValueField = "Id_provincia";
                    ComboProvincia.DataTextField = "NombreProv";
                    ComboProvincia.DataBind();
                }
            }*/
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           if (Page.IsValid)
            {
                SqlConnection conn = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='c:\users\emylavenia\documents\visual studio 2015\Projects\Ingreso\Ingreso\App_Data\IngresoDB.mdf';Integrated Security=True"
                    );

                String txt =
                   "insert into Alumno (DNI, Apellido, Nombre, Direccion, Telefono, Correo_Electronico, Id_provincia) values('" + TextBox3.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox4.Text + "'," + TextBox5.Text + ",'" + TextBox6.Text + "'," + ComboProvincia.SelectedValue + ")";
                SqlCommand sql = new SqlCommand(txt, conn);

                conn.Open();
                sql.ExecuteNonQuery();
                Response.Redirect("Confirmacion.aspx");

            }
           else
           {
               Response.Write("<script>window.alert('Debe Confirmar sus datos');</script>");

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           
        }

       

        protected void ComboProvincia_SelectedIndexChanged2(object sender, EventArgs e)
        {
           //  TextBox8.Text = Convert.ToString(ComboProvincia.SelectedValue);

         /*   SqlConnection conn = new SqlConnection();
            string cad = "select * from Provincia where NombreProv= '" + ComboProvincia.SelectedValue + "'";
            SqlCommand cn = new SqlCommand(cad, conn);
            conn.Open();

            SqlDataReader leer = cn.ExecuteReader();

            if (leer.Read() == true)
            {
                TextBox8.Text = leer["Id_provincia"].ToString();
            }
            else { }
            conn.Close();*/
        }
    }
}